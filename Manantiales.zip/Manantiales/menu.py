from tipos import TipoPrenda


def pedir_texto(mensaje, permitir_vacio=False):
    while True:
        valor = input(mensaje).strip()
        if valor or permitir_vacio:
            return valor
        print("  Este campo no puede estar vacío.")


def pedir_entero(mensaje, minimo, maximo=None):
    while True:
        try:
            numero = int(input(mensaje).strip())
        except ValueError:
            print("  Escribe un número entero.")
            continue
        if numero < minimo or (maximo is not None and numero > maximo):
            print("  Número fuera de rango.")
            continue
        return numero


def confirmar(mensaje):
    while True:
        respuesta = input(f"{mensaje} (s/n): ").strip().lower()
        if respuesta in ("s", "si", "sí"):
            return True
        if respuesta in ("n", "no"):
            return False
        print("  Responde 's' o 'n'.")


def barra(actual, total, ancho=20):
    proporcion = min(actual / total, 1) if total > 0 else 0
    llenos = round(proporcion * ancho)
    return f"[{'#' * llenos}{'-' * (ancho - llenos)}] {round(proporcion * 100)}%"


class MenuConsola:
    def __init__(self, sistema):
        self.sistema = sistema

    def ejecutar(self):
        acciones = {
            "1": ("Crear lote", self.crear_lote),
            "2": ("Escanear prendas", self.escanear),
            "3": ("Ver progreso", self.ver_progreso),
            "4": ("Ver lotes abiertos", self.ver_lotes_abiertos),
            "5": ("Editar prenda", self.editar_prenda),
            "6": ("Eliminar prenda", self.eliminar_prenda),
            "7": ("Cerrar lote", self.cerrar_lote),
            "8": ("Lotes cerrados", self.ver_lotes_cerrados),
            "0": ("Salir", None),
        }
        try:
            while True:
                print("\n===== ESCÁNER DE PRENDAS =====")
                for clave, (texto, _) in acciones.items():
                    print(f"  {clave}. {texto}")
                opcion = input("Opción: ").strip()
                if opcion == "0":
                    break
                if opcion not in acciones:
                    print("Opción no válida.")
                    continue
                try:
                    acciones[opcion][1]()
                except ValueError as error:
                    print(f"\n[!] {error}")
        except (EOFError, KeyboardInterrupt):
            print()
        print("Hasta luego.")

    # ---------- Selección ----------

    def elegir_lote(self, lotes, mensaje):
        if not lotes:
            print("\nNo hay lotes disponibles para esta acción.")
            return None
        print(f"\n{mensaje}")
        for i, lote in enumerate(lotes, start=1):
            print(f"  {i}. {lote.codigo}  ({lote.total_escaneadas()}/{lote.total_requerido()} prendas)")
        print("  0. Cancelar")
        numero = pedir_entero("Elige: ", 0, len(lotes))
        if numero == 0:
            return None
        return lotes[numero - 1]

    def elegir_tipo(self, lote, ignorar=None):
        """Pide el tipo y avisa si el lote no lo admite. Devuelve None si se cancela."""
        tipos = list(TipoPrenda)
        while True:
            print(f"\nTipo de prenda ({lote.codigo}):")
            for i, tipo in enumerate(tipos, start=1):
                if lote.requerido(tipo) == 0:
                    estado = "no aplica en este lote"
                else:
                    estado = f"{lote.cantidad(tipo)}/{lote.requerido(tipo)}"
                print(f"  {i}. {str(tipo):<10} {estado}")
            tipo = tipos[pedir_entero("Elige el tipo: ", 1, len(tipos)) - 1]
            try:
                lote.verificar_cupo(tipo, ignorar)
                return tipo
            except ValueError as error:
                print(f"\n[!] {error}")
                if not confirmar("¿Quieres elegir otro tipo?"):
                    return None

    def buscar_prenda_editable(self, mensaje):
        codigo = pedir_texto(mensaje)
        encontrada = self.sistema.buscar_prenda(codigo)
        if encontrada is None:
            raise ValueError(f"No existe ninguna prenda con el código {codigo.upper()}.")
        lote, prenda = encontrada
        lote.verificar_abierto()
        return lote, prenda

    # ---------- Visualización ----------

    def mostrar_lote(self, lote):
        estado = "CERRADO" if lote.cerrado else "ABIERTO"
        print(f"\n{lote.codigo} [{estado}] - {lote.total_escaneadas()}/{lote.total_requerido()} prendas")
        for tipo, requerido in lote.condiciones.items():
            print(f"    {str(tipo):<10} {lote.cantidad(tipo)}/{requerido}")
        if lote.prendas:
            print("    Prendas:")
            for prenda in lote.prendas:
                print(f"      - {prenda}")
        else:
            print("    (sin prendas escaneadas)")

    def ver_lotes_abiertos(self):
        print("\n=== LOTES ABIERTOS ===")
        lotes = self.sistema.lotes_abiertos()
        if not lotes:
            print("No hay lotes abiertos.")
        for lote in lotes:
            self.mostrar_lote(lote)

    def ver_lotes_cerrados(self):
        print("\n=== LOTES CERRADOS ===")
        lotes = self.sistema.lotes_cerrados()
        if not lotes:
            print("Aún no hay lotes cerrados.")
        for lote in lotes:
            self.mostrar_lote(lote)

    def ver_progreso(self):
        sistema = self.sistema
        print("\n=== PROGRESO DEL ESCANEO ===")
        if not sistema.lotes:
            print("Aún no hay lotes creados.")
            return
        total = sistema.total_escaneadas()
        requerido = sistema.total_requerido()
        print(f"Prendas escaneadas en todos los lotes: {total} de {requerido}")
        print(f"  {barra(total, requerido)}")
        print(f"Lotes: {len(sistema.lotes_abiertos())} abiertos, {len(sistema.lotes_cerrados())} cerrados")
        escaneadas = sistema.escaneadas_por_tipo()
        requeridas = sistema.requeridas_por_tipo()
        print("\nPor tipo (todos los lotes):")
        for tipo in TipoPrenda:
            print(f"  {str(tipo):<10} {escaneadas[tipo]}/{requeridas[tipo]}")
        print("\nPor lote:")
        for lote in sistema.lotes:
            estado = "CERRADO" if lote.cerrado else "ABIERTO"
            print(
                f"  {lote.codigo} [{estado:<7}] {lote.total_escaneadas()}/{lote.total_requerido()}  "
                f"{barra(lote.total_escaneadas(), lote.total_requerido())}"
            )

    # ---------- Acciones ----------

    def crear_lote(self):
        print("\n--- Crear lote ---")
        print("Indica cuántas prendas de cada tipo debe tener el lote para poder cerrarse (cantidades exactas).")
        condiciones = {}
        for tipo in TipoPrenda:
            condiciones[tipo] = pedir_entero(f"  Cantidad de {tipo} (0 si no lleva): ", 0)
        lote = self.sistema.crear_lote(condiciones)  # avisa si todas las cantidades son 0
        print(f"\nLote creado: {lote.codigo}")
        self.mostrar_lote(lote)

    def escanear(self):
        lote = self.elegir_lote(self.sistema.lotes_abiertos(), "¿En qué lote vas a escanear?")
        if lote is None:
            return
        print(f"\nEscaneando en {lote.codigo}. Deja el código vacío para terminar.")
        while True:
            if lote.esta_completo():
                print(f"\nEl lote {lote.codigo} ya tiene todas las prendas que pide. Ciérralo desde el menú (opción 7).")
                return
            codigo = pedir_texto("\nCódigo de la prenda: ", permitir_vacio=True)
            if not codigo:
                return
            try:
                self.escanear_una(lote, codigo)
            except ValueError as error:
                print(f"\n[!] {error}")

    def escanear_una(self, lote, codigo):
        existente = self.sistema.buscar_prenda(codigo)
        if existente is not None:
            self.resolver_duplicado(existente[0], existente[1])
            return
        nombre = pedir_texto("Nombre de la prenda: ")
        tipo = self.elegir_tipo(lote)
        if tipo is None:
            print("  Escaneo cancelado.")
            return
        prenda = self.sistema.escanear_prenda(lote, codigo, nombre, tipo)
        print(f"\n  Agregada: {prenda} -> {lote.codigo} ({lote.total_escaneadas()}/{lote.total_requerido()})")

    def resolver_duplicado(self, lote, prenda):
        print(f"\n[!] Prenda duplicada: el código {prenda.codigo} ya está registrado como "
              f"'{prenda.nombre}' ({prenda.tipo}) en {lote.codigo}.")
        if lote.cerrado:
            print("  Ese lote está cerrado y no se puede modificar. No se agregó nada.")
            return
        print("  ¿Qué deseas hacer?")
        print("  1. Cancelar y dejar la prenda existente como está")
        print(f"  2. Reemplazar el nombre y el tipo de la existente (se queda en {lote.codigo})")
        if pedir_entero("Elige: ", 1, 2) == 1:
            print("  Escaneo cancelado.")
            return
        nombre = pedir_texto("Nuevo nombre: ")
        tipo = self.elegir_tipo(lote, ignorar=prenda)
        if tipo is None:
            print("  Reemplazo cancelado.")
            return
        self.sistema.editar_prenda(lote, prenda, prenda.codigo, nombre, tipo)
        print(f"\n  Prenda actualizada: {prenda} en {lote.codigo}")

    def editar_prenda(self):
        lote, prenda = self.buscar_prenda_editable("\nCódigo de la prenda a editar: ")
        print(f"\nPrenda actual: {prenda} en {lote.codigo}")
        print("Deja vacío lo que no quieras cambiar.")
        codigo = pedir_texto(f"Nuevo código [{prenda.codigo}]: ", permitir_vacio=True) or prenda.codigo
        nombre = pedir_texto(f"Nuevo nombre [{prenda.nombre}]: ", permitir_vacio=True) or prenda.nombre
        tipo = prenda.tipo
        if confirmar(f"¿Cambiar el tipo (actual: {prenda.tipo})?"):
            tipo = self.elegir_tipo(lote, ignorar=prenda)
            if tipo is None:
                print("  Edición cancelada.")
                return
        self.sistema.editar_prenda(lote, prenda, codigo, nombre, tipo)
        print(f"\n  Prenda actualizada: {prenda} en {lote.codigo}")

    def eliminar_prenda(self):
        lote, prenda = self.buscar_prenda_editable("\nCódigo de la prenda a eliminar: ")
        if not confirmar(f"¿Eliminar {prenda} de {lote.codigo}?"):
            print("  Eliminación cancelada.")
            return
        self.sistema.eliminar_prenda(lote, prenda)
        print(f"\n  Prenda eliminada: {prenda}")

    def cerrar_lote(self):
        lote = self.elegir_lote(self.sistema.lotes_abiertos(), "¿Qué lote quieres cerrar?")
        if lote is None:
            return
        self.mostrar_lote(lote)
        lote.verificar_cierre()  # avisa qué falta o sobra si no cumple las condiciones
        print("\nEl lote cumple todas las condiciones de cierre.")
        if not confirmar("Una vez cerrado ya no se podrá mover ni editar. ¿Cerrarlo?"):
            print("  Cierre cancelado.")
            return
        self.sistema.cerrar_lote(lote)
        print(f"\nLote {lote.codigo} cerrado.")
