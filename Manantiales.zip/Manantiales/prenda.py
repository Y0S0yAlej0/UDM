class Prenda:
    """Una prenda. El código la identifica; el nombre solo se usa para mostrar."""

    def __init__(self, codigo, nombre, tipo):
        self.codigo = codigo.strip().upper()
        self.nombre = nombre.strip()
        self.tipo = tipo

    def __str__(self):
        return f"[{self.codigo}] {self.nombre} ({self.tipo})"
