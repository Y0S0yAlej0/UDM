from menu import MenuConsola
from sistema_escaneo import SistemaEscaneo

if __name__ == "__main__":
    MenuConsola(SistemaEscaneo()).ejecutar()
