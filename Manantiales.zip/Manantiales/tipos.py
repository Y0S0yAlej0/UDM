from enum import Enum


class TipoPrenda(Enum):
    PANTALON = "Pantalon"
    CAMISA = "Camisa"
    FALDA = "Falda"
    BUZO = "Buzo"

    def __str__(self):
        return self.value
