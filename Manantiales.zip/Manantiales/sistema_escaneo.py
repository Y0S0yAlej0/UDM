from lote import Lote
from prenda import Prenda
from tipos import TipoPrenda


class SistemaEscaneo:
    """Maneja los lotes y evita que un código de prenda se repita en cualquier lote."""

    def __init__(self):
        self.lotes = []

    def crear_lote(self, condiciones):
        if sum(condiciones.values()) == 0:
            raise ValueError("El lote debe pedir al menos una prenda.")
        codigo = f"LOTE-{len(self.lotes) + 1:03d}"
        lote = Lote(codigo, condiciones)
        self.lotes.append(lote)
        return lote

    def lotes_abiertos(self):
        return [lote for lote in self.lotes if not lote.cerrado]

    def lotes_cerrados(self):
        return [lote for lote in self.lotes if lote.cerrado]

    def buscar_prenda(self, codigo):
        """Devuelve (lote, prenda) si el código ya existe en algún lote; si no, None."""
        codigo = codigo.strip().upper()
        for lote in self.lotes:
            for prenda in lote.prendas:
                if prenda.codigo == codigo:
                    return lote, prenda
        return None

    def escanear_prenda(self, lote, codigo, nombre, tipo):
        if self.buscar_prenda(codigo) is not None:
            raise ValueError(f"El código {codigo.strip().upper()} ya está registrado.")
        prenda = Prenda(codigo, nombre, tipo)
        lote.agregar(prenda)
        return prenda

    def editar_prenda(self, lote, prenda, codigo, nombre, tipo):
        lote.verificar_cupo(tipo, ignorar=prenda)  # también revisa que el lote esté abierto
        codigo = codigo.strip().upper()
        if codigo != prenda.codigo and self.buscar_prenda(codigo) is not None:
            raise ValueError(f"El código {codigo} ya está registrado.")
        prenda.codigo = codigo
        prenda.nombre = nombre.strip()
        prenda.tipo = tipo

    def eliminar_prenda(self, lote, prenda):
        lote.quitar(prenda)

    def cerrar_lote(self, lote):
        lote.cerrar()

    # ---------- Progreso ----------

    def total_escaneadas(self):
        return sum(lote.total_escaneadas() for lote in self.lotes)

    def total_requerido(self):
        return sum(lote.total_requerido() for lote in self.lotes)

    def escaneadas_por_tipo(self):
        return {tipo: sum(lote.cantidad(tipo) for lote in self.lotes) for tipo in TipoPrenda}

    def requeridas_por_tipo(self):
        return {tipo: sum(lote.requerido(tipo) for lote in self.lotes) for tipo in TipoPrenda}
