from tipos import TipoPrenda


class Lote:
    """Grupo de prendas con condiciones de cierre exactas (cantidad por tipo)."""

    def __init__(self, codigo, condiciones):
        self.codigo = codigo
        self.condiciones = {}
        for tipo in TipoPrenda:
            if condiciones.get(tipo, 0) > 0:
                self.condiciones[tipo] = condiciones[tipo]
        self.prendas = []
        self.cerrado = False

    def total_requerido(self):
        return sum(self.condiciones.values())

    def total_escaneadas(self):
        return len(self.prendas)

    def requerido(self, tipo):
        return self.condiciones.get(tipo, 0)

    def cantidad(self, tipo):
        return sum(1 for prenda in self.prendas if prenda.tipo == tipo)

    def verificar_abierto(self):
        if self.cerrado:
            raise ValueError(f"El lote {self.codigo} está cerrado: ya no se puede modificar.")

    def verificar_cupo(self, tipo, ignorar=None):
        """Avisa (con ValueError) si el lote no puede recibir una prenda de ese tipo.

        `ignorar` es la prenda que se está editando, para que no cuente contra su propio cupo.
        """
        self.verificar_abierto()
        requerido = self.requerido(tipo)
        if requerido == 0:
            raise ValueError(f"El lote {self.codigo} no pide prendas de tipo {tipo}.")
        actual = self.cantidad(tipo)
        if ignorar is not None and ignorar.tipo == tipo:
            actual -= 1
        if actual >= requerido:
            raise ValueError(
                f"El lote {self.codigo} ya tiene las {requerido} prendas de tipo {tipo} que necesita."
            )

    def agregar(self, prenda):
        self.verificar_cupo(prenda.tipo)
        self.prendas.append(prenda)

    def quitar(self, prenda):
        self.verificar_abierto()
        self.prendas.remove(prenda)

    def diferencias(self):
        """Tipo -> (escaneadas - requeridas), solo de los tipos que no cuadran."""
        resultado = {}
        for tipo in TipoPrenda:
            diferencia = self.cantidad(tipo) - self.requerido(tipo)
            if diferencia != 0:
                resultado[tipo] = diferencia
        return resultado

    def esta_completo(self):
        return len(self.diferencias()) == 0

    def verificar_cierre(self):
        self.verificar_abierto()
        diferencias = self.diferencias()
        if diferencias:
            faltan = [f"{-d} {tipo}" for tipo, d in diferencias.items() if d < 0]
            sobran = [f"{d} {tipo}" for tipo, d in diferencias.items() if d > 0]
            partes = []
            if faltan:
                partes.append("faltan " + ", ".join(faltan))
            if sobran:
                partes.append("sobran " + ", ".join(sobran))
            raise ValueError(
                f"El lote {self.codigo} no cumple las condiciones de cierre: " + "; ".join(partes) + "."
            )

    def cerrar(self):
        self.verificar_cierre()
        self.cerrado = True
